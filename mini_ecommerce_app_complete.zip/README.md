# mini_ecommerce_app

A mini e-commerce Flutter application for CSC303 Assignment 4.

## Features
- Product List Screen (GridView)
- Product Details Screen with quantity selector
- Cart Screen with increase/decrease/remove functionality
- Checkout Screen with order summary
- Named Routes navigation
- Provider state management
- Hero animation transitions

## Getting Started

```bash
flutter pub get
flutter run
```
