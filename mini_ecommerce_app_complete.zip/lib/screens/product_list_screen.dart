import 'package:flutter/material.dart';
import '../models/product.dart';
import '../widgets/product_card.dart';

class ProductListScreen extends StatelessWidget {
  ProductListScreen({super.key});

  final List<Product> products = const [
    Product(
      id: '1',
      name: 'Wireless Headphones',
      price: 59.99,
      description: 'High-quality wireless headphones with noise cancellation and 20-hour battery life.',
      imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400',
    ),
    Product(
      id: '2',
      name: 'Smart Watch',
      price: 129.99,
      description: 'Fitness tracking smartwatch with heart rate monitor and GPS.',
      imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400',
    ),
    Product(
      id: '3',
      name: 'Running Shoes',
      price: 89.99,
      description: 'Lightweight running shoes with breathable mesh upper.',
      imageUrl: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400',
    ),
    Product(
      id: '4',
      name: 'Backpack',
      price: 45.99,
      description: 'Durable waterproof backpack with laptop compartment.',
      imageUrl: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400',
    ),
    Product(
      id: '5',
      name: 'Sunglasses',
      price: 34.99,
      description: 'UV protection polarized sunglasses with stylish frame.',
      imageUrl: 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=400',
    ),
    Product(
      id: '6',
      name: 'Bluetooth Speaker',
      price: 49.99,
      description: 'Portable Bluetooth speaker with 360 surround sound.',
      imageUrl: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mini Shop', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.pushNamed(context, '/cart');
            },
          ),
        ],
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.75,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
        ),
        itemCount: products.length,
        itemBuilder: (ctx, index) => ProductCard(product: products[index]),
      ),
    );
  }
}
